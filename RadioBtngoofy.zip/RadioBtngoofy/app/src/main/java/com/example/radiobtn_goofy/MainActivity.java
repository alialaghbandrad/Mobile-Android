package com.example.radiobtn_goofy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();
    }

    private void initialize() {
        radioGroup = findViewById(R.id.radioGroup);
        imageView = findViewById(R.id.imageView);
    }

    public void runMe(View view) {
        int selectedRadioBtn = radioGroup.getCheckedRadioButtonId();

        switch (selectedRadioBtn) {
            case R.id.radioButton1:
                imageView.setImageResource(R.drawable.goofy18);
                break;
            case R.id.radioButton2:
                imageView.setImageResource(R.drawable.e);
                break;
            case R.id.radioButton3:
                imageView.setImageResource(R.drawable.edd);
                break;
        }
    }
}