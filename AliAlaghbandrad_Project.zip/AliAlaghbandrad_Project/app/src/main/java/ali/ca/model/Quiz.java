package ali.ca.model;

import java.io.Serializable;

public class Quiz implements Comparable , Serializable {
    private String operation;
    private String validation;
    private double answer;

    public Quiz(String operation, String validation, double answer) {
        this.operation = operation;
        this.validation = validation;
        this.answer = answer;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getValidation() {
        return validation;
    }

    public void setValidation(String validation) {
        this.validation = validation;
    }

    public double getAnswer() {
        return answer;
    }

    public void setAnswer(double answer) {
        this.answer = answer;
    }

    @Override
    public String toString() {
        return "Your answer " + answer +" for '"+  operation + "'  is "+ validation;
    }

    @Override
    public int compareTo(Object o) {
        Quiz otherObject = (Quiz) o;
        return validation.compareTo(otherObject.getValidation());
    }
}
