package ali.ca;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import ali.ca.model.Quiz;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher, DialogInterface.OnClickListener {

    EditText editTextAnswer;
    TextView textViewTitleMathQuiz,textViewOperation,textViewValidation;
    Button btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btnDot,btn0,btnNegative,btnGenerate,btnValidate,btnClear,btnScore,btnFinish;

    ArrayList<Quiz> listOfMathQuiz;

    int btnId[];
    Button buttonI[];

    String enteredAnswer;
    boolean flag = true;
    float rightAnswer;
    String operation = null;
    String validation;

    final static int REQUEST_CODE1 = 1;

    AlertDialog alertDialog;
    AlertDialog.Builder alertDialog_Builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();
    }

    private void initialize() {

        listOfMathQuiz = new ArrayList<>();

        textViewTitleMathQuiz = findViewById(R.id.textViewTitleMathQuiz);
        editTextAnswer = findViewById(R.id.editTextAnswer);
        textViewOperation = findViewById(R.id.textViewOperation);
        textViewValidation = findViewById(R.id.textViewValidation);

        btnDot=findViewById(R.id.btnDot);
        btnDot.setOnClickListener(this);

        btnNegative = findViewById(R.id.btnNegative);
        btnNegative.setOnClickListener(this);

        btnGenerate = findViewById(R.id.btnGenerate);
        btnGenerate.setOnClickListener(this);

        btnValidate = findViewById(R.id.btnValidate);
        btnValidate.setOnClickListener(this);

        btnClear = findViewById(R.id.btnClear);
        btnClear.setOnClickListener(this);

        btnScore = findViewById(R.id.btnScore);
        btnScore.setOnClickListener(this);

        btnFinish = findViewById(R.id.btnFinish);
        btnFinish.setOnClickListener(this);

        // Array of button Ids
        btnId = new int[]{R.id.btn0,R.id.btn1,R.id.btn2,R.id.btn3,R.id.btn4,R.id.btn5,R.id.btn6,R.id.btn7,R.id.btn8,R.id.btn9};

        // Array of 10 buttons
        buttonI=new Button[10];

        // Find all 0-9 buttons from array of buttons and enable click
        for (int i=0; i<10; i++) {
            buttonI[i] = findViewById(btnId[i]);
            buttonI[i].setOnClickListener(this);
        }

        btnValidate.setEnabled(false);
        editTextAnswer.addTextChangedListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.btnGenerate:
                goGenerateQuestion();
                break;

            case R.id.btnValidate:
                goValidate();
                break;

            case R.id.btnClear:
                goClear();
                break;

            case R.id.btnScore:
                goResult();
                break;

            case R.id.btnFinish:
                showExitAlertDialog();
                break;
            case R.id.btnDot:
                goDot();
                break;

            case R.id.btnNegative:
                goNegative();

                break;
            default:
                for (int i=0;i<10;i++)
                {
                    if(v.getId()==btnId[i])
                        goNumber(i);
                }
        }
    }

    private void goGenerateQuestion() {
        flag = false;
        editTextAnswer.setText(null);   // clear editTextAnswer
        textViewValidation.setText(null);   // clear textViewValidation
        flag = true;
        btnValidate.setEnabled(false);  // De-active btnValidate

        Random random = new Random();
        int operand1 = random.nextInt(10); // generate random integer between 0-9
        int operand2 = random.nextInt(10); // generate random integer between 0-9
        int operator = random.nextInt(4); // generate random integer between 0-3 to choose among +/-/*/divide "/"

        while (operand2 == 0 && operator == 3) {    //handle divide 0
            operand2 = random.nextInt(10);
        }

        String selectedRandomOperator;

        switch (operator) {
            case 0:
                selectedRandomOperator = "+";
                rightAnswer = operand1 + operand2;
                break;
            case 1:
                selectedRandomOperator = "-";
                rightAnswer = operand1 - operand2;
                break;
            case 2:
                selectedRandomOperator = "*";
                rightAnswer = operand1 * operand2;
                break;
            case 3:
                selectedRandomOperator = "/";
                rightAnswer = (float) operand1 / operand2;
                break;
            default:
                selectedRandomOperator = "";
        }

        operation = String.valueOf(operand1) + " " + selectedRandomOperator + " " + String.valueOf(operand2) + " = ?"; // Create generated operation question
        textViewOperation.setText(operation); // show generated operation question

    }

    private void goValidate() {
        try {
            Float answerOfUser = Float.valueOf(editTextAnswer.getText().toString()); // Get user entered answer
            String answerResult;
            if (answerOfUser == rightAnswer) {
                textViewValidation.setTextColor(Color.parseColor("#049F0A"));
                answerResult = "Correct Answer!";
                validation = "RIGHT";
            } else {
                textViewValidation.setTextColor(Color.parseColor("#FFBF0F0F"));
                answerResult = "Wrong Answer!";
                validation = "WRONG";
            }

            textViewValidation.setText(answerResult); // Show if answer was correct/wrong on textViewValidation
            Quiz quiz = new Quiz(operation, validation, answerOfUser);
            listOfMathQuiz.add(quiz);

        } catch (Exception e) {
            Toast.makeText(this, "Please enter an answer! ", Toast.LENGTH_LONG).show();
        }
    }

    private void goClear() {
        flag = false;
        editTextAnswer.setText(null);
        textViewOperation.setText("0 + 0");
        textViewValidation.setText(null);
        btnValidate.setEnabled(false);
        flag=true;
    }

    private void goResult() {
        try {
            int totalScore = 0;
            int quizNumber = 0;
            int scorePercentage;

            Iterator<Quiz> iterator = listOfMathQuiz.iterator();

            while (iterator.hasNext()) {
                Quiz quiz = iterator.next();
                if (quiz.getValidation().equals("RIGHT")) {
                    totalScore+=1;
                }
                quizNumber++;
            }

            scorePercentage = (totalScore*100)/quizNumber;

            Bundle bundle = new Bundle();
            bundle.putSerializable("bundle", listOfMathQuiz);

            Intent intent = new Intent(this, Result.class);
            intent.putExtra("intent", bundle);
            intent.putExtra("scorePercentage", scorePercentage);

            startActivityForResult(intent, REQUEST_CODE1);
        } catch(Exception e){
            Toast.makeText(this, "No score available! ", Toast.LENGTH_LONG).show();
        }
    }

    public void showExitAlertDialog() {

        //Using the alert
        alertDialog_Builder = new AlertDialog.Builder(this);

        alertDialog_Builder.setTitle("Exit Confirmation");
        alertDialog_Builder.setMessage("Do you want to exit (Y/N)");

        alertDialog_Builder.setPositiveButton("Yes", this);
        alertDialog_Builder.setNegativeButton("No", this);

        alertDialog = alertDialog_Builder.create();

        alertDialog.show();
    }

    private void goDot() {
        if (editTextAnswer.getText().toString().contains(".")) {
            Toast toastException=Toast.makeText(this,
                    "Invalid Entry: Only one Dot is allowed",Toast.LENGTH_SHORT);
            toastException.setGravity(Gravity.TOP|Gravity.CENTER,0,400);
            toastException.show();
        } else {
            flag = false;
            enteredAnswer = "";
            enteredAnswer = editTextAnswer.getText() + ".";
            editTextAnswer.setText(enteredAnswer);
            flag = true;
        }
    }

    private void goNegative() {
        String str = editTextAnswer.getText().toString();
        int lenght = str.length();
        if (editTextAnswer.getText().toString().contains("-") || lenght>=1) { // negative should be in front of number
            Toast toastException=Toast.makeText(this,"Invalid Entry: Negative must be in front of number",
                    Toast.LENGTH_SHORT);
            toastException.setGravity(Gravity.TOP|Gravity.CENTER,0,400);
            toastException.show();
        } else {
            flag = false;
            enteredAnswer = "-";
            editTextAnswer.setText(enteredAnswer);
            flag = true;
        }
    }

    private void goNumber(int i){
        enteredAnswer = editTextAnswer.getText() + String.valueOf(i); // existing answer + new number pressed by button
        editTextAnswer.setText(enteredAnswer);  // updating answer
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        if(!flag) return;
        try {
            Float enteredValueOfAnswer = Float.valueOf(editTextAnswer.getText().toString());

            if(textViewOperation.getText().toString().equals("0 + 0")){
                Toast toast=Toast.makeText(this,"First, Press Generate Button!",Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.TOP|Gravity.CENTER,0,400);
                toast.show();
            }
            if (enteredValueOfAnswer> 81) {
                Toast toastException=Toast.makeText(this,"Answer cannot be greater than 81",Toast.LENGTH_SHORT);
                toastException.setGravity(Gravity.TOP|Gravity.CENTER,0,400);
                toastException.show();
                btnValidate.setEnabled(false);
            } else {
                btnValidate.setEnabled(true);
            }
        } catch (Exception e){
            Toast toastException=Toast.makeText(this,"Enter numbers only",Toast.LENGTH_SHORT);
            toastException.setGravity(Gravity.TOP|Gravity.CENTER,0,400);
            toastException.show();
        }
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        switch (which) {
            case DialogInterface.BUTTON_POSITIVE:
                finish();
                break;

            case DialogInterface.BUTTON_NEGATIVE:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        goClear();
        if (requestCode == REQUEST_CODE1) {
            String receivedMessage = (String) data.getStringExtra("message");
            if (resultCode == RESULT_OK) {
                textViewTitleMathQuiz.setText(receivedMessage);
            }
        }
    }
}