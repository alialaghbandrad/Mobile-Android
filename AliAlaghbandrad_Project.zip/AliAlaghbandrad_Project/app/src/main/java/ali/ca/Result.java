package ali.ca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Movie;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import ali.ca.model.Quiz;

public class Result extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Spinner spinnerResult;

    ArrayAdapter<String> resultAdapter;
    ArrayAdapter<Quiz> quizArrayAdapter;

    String[] resultChoices = {"All Answers", "Right Answers", "Wrong Answers"};

    ArrayList<Quiz> listofMathQuiz;
    ArrayList<Quiz> rightAnswerlist;
    ArrayList<Quiz> wrongAnswerList;

    ListView listViewResultShow;
    EditText editTextRegister;
    TextView textViewScore;
    Button btnBack, btnSortAsc, btnSortDes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        initialize();
        getMyIntent();
    }

    private void initialize() {
        spinnerResult = findViewById(R.id.spinnerResult);
        spinnerResult.setOnItemSelectedListener(this);
        resultAdapter = new ArrayAdapter<>(
                this,
                R.layout.support_simple_spinner_dropdown_item,
                resultChoices
        );
        spinnerResult.setAdapter(resultAdapter);

        rightAnswerlist = new ArrayList<>();
        wrongAnswerList = new ArrayList<>();

        listViewResultShow = findViewById(R.id.listViewResultShow);
        editTextRegister = findViewById(R.id.register);
        textViewScore = findViewById(R.id.score);

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);

        btnSortAsc = findViewById(R.id.btnSortAsc);
        btnSortAsc.setOnClickListener(this);

        btnSortDes = findViewById(R.id.btnSortDes);
        btnSortDes.setOnClickListener(this);

    }

    private void getMyIntent() {
        Bundle bundle = getIntent().getBundleExtra("intent");
        Serializable bundledListOfMathQuiz = bundle.getSerializable("bundle");

        listofMathQuiz = (ArrayList<Quiz>) bundledListOfMathQuiz;

        Intent intent = getIntent();
        int scorePercentage = intent.getIntExtra("scorePercentage", 0);
        textViewScore.setText(scorePercentage + "%");

        quizArrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                listofMathQuiz
        );
        listViewResultShow.setAdapter(quizArrayAdapter);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btnBack:
                goMainPage();
                break;
            case R.id.btnSortAsc:
                sortAscending();
                break;
            case R.id.btnSortDes:
                sortDescending();
                break;
        }
    }

    private void goMainPage() {
        String Name = editTextRegister.getText().toString();
        String Score = textViewScore.getText().toString();

        String message = Name + " your score is " + Score + " !";

        Intent intent = new Intent();
        intent.putExtra("message", message);

        setResult(RESULT_OK, intent);
        finish();
    }

    private void rightAnswerList(ArrayList<Quiz> listofMathQuiz) {

        Iterator<Quiz> iterator = listofMathQuiz.iterator();
        rightAnswerlist.clear();
        while (iterator.hasNext()) {
            Quiz operation = iterator.next();
            if (operation.getValidation().equals("RIGHT")) {
                rightAnswerlist.add(operation);
            }
        }
        ListView ResultList = findViewById(R.id.listViewResultShow);
        ArrayAdapter<Quiz> listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rightAnswerlist);
        ResultList.setAdapter(listAdapter);
    }

    private void wrongAnswerList(ArrayList<Quiz> listofMathQuiz) {

        Iterator<Quiz> iterator = listofMathQuiz.iterator();
        wrongAnswerList.clear();
        while (iterator.hasNext()) {

            Quiz operation = iterator.next();

            if (operation.getValidation().equals("WRONG")) {

                wrongAnswerList.add(operation);
            }
        }
        ListView ResultList = findViewById(R.id.listViewResultShow);
        ArrayAdapter<Quiz> listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, wrongAnswerList);
        ResultList.setAdapter(listAdapter);
    }


    // Spinner selection
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (position) {
            case 0:
                getMyIntent();
                btnSortAsc.setEnabled(true);
                btnSortDes.setEnabled(true);
                break;
            case 1:
                rightAnswerList(listofMathQuiz);
                btnSortAsc.setEnabled(false);
                btnSortDes.setEnabled(false);
                break;
            case 2:
                wrongAnswerList(listofMathQuiz);
                btnSortAsc.setEnabled(false);
                btnSortDes.setEnabled(false);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void sortAscending() {

            Collections.sort(listofMathQuiz);
            ArrayAdapter<Quiz> listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listofMathQuiz);
            listViewResultShow.setAdapter(listAdapter);
    }

    private void sortDescending() {

        Collections.sort(listofMathQuiz, Collections.reverseOrder());
        ArrayAdapter<Quiz> listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listofMathQuiz);
        listViewResultShow.setAdapter(listAdapter);

    }
}